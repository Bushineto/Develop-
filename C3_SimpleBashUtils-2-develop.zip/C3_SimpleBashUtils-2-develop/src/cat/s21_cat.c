#include "s21_cat.h"  // Включение заголовочного файла s21_cat.h

int main(int argc, char* argv[]) {
  Flags flags = {
      0};  // Создание структуры Flags и инициализация всех полей нулями
  parseCommandLineArguments(
      argc, argv, &flags);  // Вызов функции parseCommandLineArguments для
                            // обработки аргументов командной строки
  int i =
      optind;  // Получение индекса следующего аргумента после обработки ключей
  for (; i < argc; i++) {
    readFile(argv[i], &flags);  // Вызов функции readFile для чтения файлов
  }
}

void parseCommandLineArguments(int argc, char* argv[], Flags* flags) {
  int currentFlag;
  struct option long_flags[] = {
      {"number-nonblank", 0, 0, 'b'},  // Определение длинных флагов
      {"number", 0, 0, 'n'},
      {"squeeze-blank", 0, 0, 's'},
      {"help", 0, NULL, 'h'},
      {0, 0, 0, 0}};
  while ((currentFlag =
              getopt_long(argc, argv, "+beEvnstTv", long_flags, NULL)) != -1) {
    // Цикл обработки флагов командной строки с использованием getopt_long
    switch (currentFlag) {
      case 'b':
        flags->b = 1;  // Установка флага b в структуре Flags
        break;
      case 'e':
        flags->e = 1;  // Установка флага e в структуре Flags
        flags->v = 1;  // Установка флага v в структуре Flags
        break;
      case 'v':
        flags->v = 1;  // Установка флага v в структуре Flags
        break;
      case 'n':
        flags->n = 1;  // Установка флага n в структуре Flags
        break;
      case 's':
        flags->s = 1;  // Установка флага s в структуре Flags
        break;
      case 't':
        flags->t = 1;  // Установка флага t в структуре Flags
        flags->v = 1;  // Установка флага v в структуре Flags
        break;
      case 'T':
        flags->t = 1;  // Установка флага t в структуре Flags
        break;
      case 'E':
        flags->e = 1;  // Установка флага e в структуре Flags
        break;
      case 'h':
        printHelpMessage();  // Вызов функции printHelpMessage для вывода
                             // справочного сообщения
        break;
      default:
        fprintf(stderr,
                "Use --help for help message\n");  // Вывод сообщения об ошибке
        exit(1);  // Выход из программы с кодом ошибки
    }
  }
}

void printHelpMessage(void) {
  fprintf(stderr, USAGE);  // Вывод справочного сообщения
  exit(0);  // Нормальное завершение программы
}

// Чтение файла и обработка флагов
void readFile(char* argv, Flags* flags) {
  FILE* file = fopen(argv, "r");  // Открытие файла для чтения

  if (file == NULL) {
    fprintf(stderr, "s21_cat: %s: No such file or directory\n",
            argv);  // Вывод сообщения об ошибке, если файл не найден
  } else {
    int line_counter = 1;  // Счетчик строк
    int flag_s = 0;        // Флаг для обработки squeeze-blank
    char c = '\0';  // Переменная для хранения символов из файла

    for (char prev = '\n'; !feof(file); prev = c) {
      c = getc(file);  // Чтение символа из файла

      // Обработка флага squeeze-blank
      if (flags->s && c == '\n' && prev == '\n') {
        flag_s++;
        if (flag_s > 1) continue;
      } else
        flag_s = 0;

      // Обработка флага number-nonblank
      if (flags->b && c != '\n' && prev == '\n' && c != EOF)
        printf("%6d\t", line_counter++);

      // Обработка флага number
      if (flags->n && !flags->b && prev == '\n' && c != EOF)
        printf("%6d\t", line_counter++);

      // Обработка флага e
      if (flags->e && c == '\n') printf("$");

      // Обработка флага t
      if (flags->t) {
        if (c == 9) {
          putchar('^');
          putchar('I');
          continue;
        }
      }

      // Обработка флага v
      if (flags->v) {
        if ((c >= 0 && c < 9) || (c > 10 && c < 32)) {
          putchar('^');
          c += 64;
        }
        if (c == 127) {
          putchar('^');
          putchar('?');
          continue;
        }
      }

      if (c != EOF) printf("%c", c);  // Вывод символа на экран
    }

    fclose(file);  // Закрытие файла
  }
}