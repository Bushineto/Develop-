#ifndef S21_CAT_H
#define S21_CAT_H

#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define BUFFER_SIZE 4096

#define USAGE "Usage: ./s21_cat [-beEvnstTv] [file ...]\n"

#define FLAGS_HEADER

typedef struct {
  int b;  // (GNU: --number-nonblank) | нумерует только непустые строки |
  int e;  // предполагает и -v | также отображает символы конца строки как $  |
  int n;  // (GNU: --number) | нумерует все выходные строки |
  int s;  // (GNU: --squeeze-blank) | сжимает несколько смежных пустых строк |
  int t;  // предполагает и -v | также отображает табы как ^I |
  int v;  // Отображает unprintable символы
} Flags;

void parseCommandLineArguments(int argc, char* argv[], Flags* flags);
void printHelpMessage(void);
void readFile(char* argv, Flags* flags);
#endif
