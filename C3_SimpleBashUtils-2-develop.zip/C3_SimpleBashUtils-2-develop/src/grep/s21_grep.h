#ifndef GREP_HEADER
#define GREP_HEADER
#define _GNU_SOURCE

// Включение необходимых заголовочных файлов
#include <getopt.h>  // Для обработки командной строки
#include <regex.h>  // Для работы с регулярными выражениями
#include <stdio.h>  // Для стандартных операций ввода-вывода
#include <stdlib.h>  // Для работы с памятью и стандартными функциями
#include <string.h>  // Для работы со строками

#define BUF 2048  // Размер буфера для строк

// Структура для хранения флагов командной строки
typedef struct flags {
  int e;  // Флаг -e (использовать регулярное выражение)
  int i;  // Флаг -i (игнорировать регистр символов)
  int v;  // Флаг -v (вывести строки, не соответствующие шаблону)
  int c;  // Флаг -c (вывести только количество соответствующих строк)
  int l;  // Флаг -l (вывести только имена файлов, содержащих соответствующие
          // строки)
  int n;  // Флаг -n (вывести номера строк)
  int h;  // Флаг -h (не выводить имена файлов)
  int s;  // Флаг -s (не выводить сообщения об ошибках)
  int f;  // Флаг -f (читать шаблон из файла)
  int o;  // Флаг -o (вывести только соответствующие фрагменты строк)
  int e_f;  // Флаг -e (использовать регулярное выражение из файла)
  char pattern[BUF];   // Шаблон поиска
  char f_file[BUF];    // Имя файла с шаблонами
  int print_filename;  // Флаг для вывода имени файла
  int multiple_files;  // Флаг для обработки нескольких файлов
} flag;

// Функция для разбора аргументов командной строки
int parseArguments(int argc, char* argv[], flag* flags);

// Функция для чтения содержимого файлов и поиска соответствующих строк
void reader(char* argv[], flag flags);

// Функция для обработки флага -e и компиляции регулярного выражения
void parseExpression(flag* flags);

// Функция для обработки флага -o и вывода соответствующих фрагментов строк
void processOutput(char* current_line, regex_t compiled, flag flags,
                   int line_counter, char* argv[]);

// Функция для вывода соответствующих строк
void printMatchedLine(char* current_line, char* argv[], flag flags,
                      int* match_found, int line_counter);

// Функция для чтения шаблона из файла
void readPatternFromFile(flag* flags, char* optarg);

#endif
