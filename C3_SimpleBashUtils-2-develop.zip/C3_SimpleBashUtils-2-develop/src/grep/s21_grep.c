#include "s21_grep.h"

int main(int argc, char* argv[]) {
  // Проверяем количество аргументов командной строки
  if (argc > 2) {
    flag flags = {0};  // Создаем структуру для хранения флагов
    // Парсим аргументы командной строки
    if (!parseArguments(argc, argv, &flags)) {
      if (flags.e_f == 0) {
        sprintf(flags.pattern, "%s",
                argv[optind]);  // Записываем паттерн поиска
        optind++;
      }
      if (argc - optind > 1)
        flags.multiple_files =
            1;  // Устанавливаем флаг, если файлов больше одного
      if (flags.multiple_files && !flags.h)
        flags.print_filename = 1;  // Устанавливаем флаг печати имени файла
      while (optind < argc) {
        reader(argv, flags);  // Читаем файлы и ищем совпадения
        optind++;
      }
    }
  }
  return 0;
}

int parseArguments(int argc, char* argv[], flag* flags) {
  int currentFlag = 0;
  int error = 0;
  const char* short_flag = "e:ivclnhsf:o";
  // Парсим аргументы командной строки
  while ((currentFlag = getopt_long(argc, argv, short_flag, 0, 0)) != -1) {
    switch (currentFlag) {
      case 'e':
        flags->e = 1;  // Устанавливаем флаг расширенных выражений
        parseExpression(flags);  // Парсим выражение для поиска
        flags->e_f = 1;
        break;
      case 'i':
        flags->i = 1;  // Устанавливаем флаг игнорирования регистра
        break;
      case 'v':
        flags->v = 1;  // Устанавливаем флаг инвертированного поиска
        break;
      case 'c':
        flags->c = 1;  // Устанавливаем флаг подсчета количества совпадений
        break;
      case 'l':
        flags->l = 1;  // Устанавливаем флаг печати имен файлов с совпадениями
        break;
      case 'n':
        flags->n = 1;  // Устанавливаем флаг печати номеров строк
        break;
      case 'h':
        flags->h = 1;  // Устанавливаем флаг скрытия имени файла
        break;
      case 's':
        flags->s = 1;  // Устанавливаем флаг скрытия ошибок файлов
        break;
      case 'f':
        flags->f = 1;  // Устанавливаем флаг чтения паттерна из файла
        readPatternFromFile(flags, optarg);  // Читаем паттерн из файла
        flags->e_f = 1;
        break;
      case 'o':
        flags->o =
            1;  // Устанавливаем флаг вывода только совпадающих фрагментов
        break;
      default:
        error = 1;  // Устанавливаем флаг ошибки
        fprintf(stderr, "usage: ./s21_grep [e:ivclnhsf:o] pattern [file...]\n");
        break;
    }
  }
  if (flags->v || flags->c || flags->l)
    flags->o = 0;  // Если указаны флаги -v, -c или -l, сбрасываем флаг -o
  return error;
}

void reader(char* argv[], flag flags) {
  FILE* file = fopen(argv[optind], "r");
  if (file == NULL) {
    if (!flags.s)
      fprintf(stderr, "s21_grep: %s: No such file or directory\n",
              argv[optind]);
  } else {
    int reg_flags = REG_EXTENDED;
    regex_t compiled;
    if (flags.i) reg_flags = REG_ICASE;
    if (regcomp(&compiled, flags.pattern, reg_flags) == 0) {
      char* current_line = NULL;
      size_t line_size = 0;
      int line_counter = 0;
      int line_found = 0;
      int match_found = 0;
      while (getline(&current_line, &line_size, file) != EOF) {
        line_counter++;
        if (flags.o) {
          processOutput(current_line, compiled, flags, line_counter, argv);
        } else {
          if (current_line)
            line_found = regexec(&compiled, current_line, 0, 0, 0);
          if (!flags.v && !line_found)
            printMatchedLine(current_line, argv, flags, &match_found,
                             line_counter);
          else if (flags.v && line_found)
            printMatchedLine(current_line, argv, flags, &match_found,
                             line_counter);
        }
      }
      if (flags.c) {
        if (flags.print_filename) printf("%s:", argv[optind]);
        if (flags.l && match_found) match_found = 1;  //-lc
        printf("%d\n", match_found);
      }
      if (flags.l && match_found) printf("%s\n", argv[optind]);
      if (current_line != NULL) free(current_line);
      regfree(&compiled);
    }
    fclose(file);
  }
}

void parseExpression(flag* flags) {
  // Парсим выражение для поиска
  if ((strlen(flags->pattern) + strlen(optarg)) < (BUF - 2)) {
    if (flags->e_f) strcat(flags->pattern, "|");
    if (strlen(optarg) == 0)
      strcat(flags->pattern, ".");
    else
      strcat(flags->pattern, optarg);
  }
}

void processOutput(char* current_line, regex_t compiled, flag flags,
                   int line_counter, char* argv[]) {
  regmatch_t pattern_match = {0};
  int opener = 1;
  if (flags.v) {
    if (regexec(&compiled, current_line, 1, &pattern_match, 0)) {
      if (flags.o) {
        ;
      } else {
        printf("%s", current_line);
      }
    }
  } else {
    if (!regexec(&compiled, current_line, 1, &pattern_match, 0)) {
      if (opener) {
        if (flags.print_filename) {
          printf("%s:%.*s\n", argv[optind],
                 (int)(pattern_match.rm_eo - pattern_match.rm_so),
                 current_line + pattern_match.rm_so);
        } else {
          printf("%.*s\n", (int)(pattern_match.rm_eo - pattern_match.rm_so),
                 current_line + pattern_match.rm_so);
        }
        if (flags.n) printf("%d:", line_counter);
        opener++;
        char* remaining = current_line + pattern_match.rm_eo;
        while (!regexec(&compiled, remaining, 1, &pattern_match, 0)) {
          printf("%.*s\n", (int)(pattern_match.rm_eo - pattern_match.rm_so),
                 remaining + pattern_match.rm_so);
          remaining += pattern_match.rm_eo;
        }
      }
    }
  }
}

void printMatchedLine(char* current_line, char* argv[], flag flags,
                      int* match_found, int line_counter) {
  if (!flags.l && !flags.c) {
    if (flags.print_filename) printf("%s:", argv[optind]);
    if (flags.n) printf("%d:", line_counter);
    char* temp = strchr(current_line, '\n');
    if (temp) *temp = '\0';
    printf("%s\n", current_line);
  }
  (*match_found)++;
}

void readPatternFromFile(flag* flags, char* optarg) {
  FILE* file = fopen(optarg, "r");
  if (file == NULL) {
    if (!flags->s)
      fprintf(stderr, "s21_grep: %s: No such file or directory\n",
              flags->f_file);
  } else {
    char current_line[1] = {'\0'};
    char current = '\0', prev = '\n';
    // Читаем символы из файла
    while ((current = fgetc(file)) != EOF) {
      if (strlen(flags->pattern) < (BUF - 2)) {
        if (flags->e_f && prev == '\n') {
          strcat(flags->pattern, "|");
        }
        if (current != '\n') {
          current_line[0] = current;
          strcat(flags->pattern, current_line);
        }
        if (current == '\n' && prev == '\n') {
          strcat(flags->pattern, ".");
        }
        if (current == '\n') flags->e_f = 1;
        prev = current;
      }
    }
    fclose(file);
  }
}
